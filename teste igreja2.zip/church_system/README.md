# Sistema de Gerenciamento de Patrimônio da Igreja

Sistema web para controlar equipamentos, instrumentos, ferramentas, cabos,
conectores, materiais de estoque, eventos e todo o histórico de movimentações
da igreja — com login de equipe, dashboard, alertas de estoque baixo e
devoluções atrasadas.

---

## 1. Arquitetura

- **Backend:** Python + Flask, organizado em *blueprints* (módulos) por área.
- **Banco de dados:** SQLite por padrão (arquivo `instance/igreja.db`),
  usando SQLAlchemy como ORM — o que permite migrar para PostgreSQL apenas
  trocando a variável de ambiente `DATABASE_URL`, sem mudar o código.
- **Frontend:** HTML + Jinja2 + Bootstrap 5 (CDN) + JavaScript simples.
  Menu lateral fixo no computador e navegação inferior + menu deslizante
  no celular.
- **Autenticação:** Flask-Login, com senhas armazenadas com hash seguro
  (`werkzeug.security`), dois papéis: `admin` e `membro`.
- **Auditoria:** toda ação relevante (login, cadastro, edição, retirada,
  devolução, entrada/saída de estoque) grava uma linha em `audit_logs`.
- **Histórico permanente:** movimentações de itens (`movements`) e de
  estoque (`stock_movements`) nunca são apagadas ou sobrescritas — apenas
  o campo "local atual" / "quantidade atual" é atualizado para consulta
  rápida.

## 2. Estrutura de pastas

```
church_system/
├── run.py                  # ponto de entrada (python run.py)
├── config.py                # configurações (lidas de variáveis de ambiente)
├── requirements.txt
├── .env.example              # copie para .env e ajuste
├── app/
│   ├── __init__.py           # application factory + registro dos blueprints
│   ├── extensions.py         # db (SQLAlchemy) e login_manager
│   ├── models.py             # todas as tabelas e relacionamentos
│   ├── utils.py               # auditoria, upload de fotos, decorator admin_required
│   ├── cli.py                  # comandos: init-db, seed-data, create-admin
│   ├── auth/routes.py          # login / logout
│   ├── main/routes.py          # dashboard e busca global
│   ├── items/routes.py         # equipamentos: CRUD, retirada, devolução, histórico
│   ├── stock/routes.py         # estoque: CRUD, entrada, saída, histórico
│   ├── events/routes.py        # eventos e vínculo com movimentações
│   ├── admin/routes.py         # usuários, categorias, locais, status, unidades, auditoria
│   ├── templates/              # todas as páginas HTML (Jinja2)
│   └── static/
│       ├── css/style.css
│       ├── js/main.js
│       └── uploads/            # fotos enviadas (criada automaticamente)
└── instance/
    └── igreja.db              # banco SQLite (criado automaticamente)
```

## 3. Modelo do banco de dados e relacionamentos

| Tabela            | Descrição                                                             |
|-------------------|------------------------------------------------------------------------|
| `users`           | Equipe com login: nome, e-mail, senha (hash), função, status, data     |
| `categories`      | Categorias personalizáveis (ícone + nome)                              |
| `locations`       | Locais físicos da igreja                                                |
| `statuses`        | Status possíveis dos itens (Disponível, Em uso, etc.), com cor          |
| `units`           | Unidades de medida do estoque (Unidade, Metro, Kit, etc.)               |
| `items`           | Itens individuais (equipamento/instrumento/ferramenta/cabo completo)   |
| `movements`       | Retiradas/devoluções de um item — histórico permanente                 |
| `stock_items`     | Materiais/conectores controlados por quantidade                        |
| `stock_movements` | Entradas/saídas de estoque — histórico permanente                      |
| `events`          | Eventos da igreja (culto, acampamento, conferência, etc.)               |
| `audit_logs`      | Registro de auditoria de ações importantes                             |

Relacionamentos principais:

- `items.category_id` → `categories.id` · `items.current_location_id` → `locations.id` · `items.status_id` → `statuses.id`
- `movements.item_id` → `items.id` (1 item tem N movimentações) · `movements.event_id` → `events.id` (opcional)
- `stock_items.category_id/unit_id/location_id` → tabelas correspondentes
- `stock_movements.stock_item_id` → `stock_items.id` (1 material tem N movimentações) · `stock_movements.event_id` → `events.id` (opcional)
- `audit_logs.user_id` → `users.id`

## 4. Fluxo das principais funções

**Retirada de equipamento:** usuário abre o item → "Registrar retirada" →
informa destino, responsável, evento (opcional), data prevista de devolução
→ o sistema cria uma linha em `movements` **e** atualiza `items.current_location_id`
e `items.status_id`. A movimentação anterior nunca é apagada.

**Devolução:** o sistema identifica a movimentação em aberto do item →
"Registrar devolução" → informa local de devolução → grava `returned_at`,
`return_location_id` na mesma linha de `movements` (não cria linha nova,
nem apaga a antiga) e volta o item para o status "Disponível".

**Saída de estoque:** informa quantidade, motivo, destino e evento
(opcional) → o sistema valida que a quantidade não fica negativa, grava uma
linha em `stock_movements` com quantidade anterior/nova e atualiza
`stock_items.quantity`.

**Dashboard:** consulta agregada de `items` (contagem por status),
`movements` (em aberto e vencidas = devolução atrasada), `stock_items`
(quantidade ≤ mínimo = estoque baixo) e `events` (próximos/andamento).

---

## 5. Instalação passo a passo

### 5.1 Instalar Python

Baixe e instale o Python 3.11 ou mais recente em https://www.python.org/downloads/
(no Windows, marque a opção "Add Python to PATH" durante a instalação).

Verifique no terminal:
```bash
python --version
```

### 5.2 Criar o ambiente virtual

Dentro da pasta `church_system`:
```bash
python -m venv venv
```
Ativar o ambiente:
- Windows: `venv\Scripts\activate`
- Mac/Linux: `source venv/bin/activate`

### 5.3 Instalar as dependências

```bash
pip install -r requirements.txt
```

### 5.4 Configurar variáveis de ambiente

```bash
cp .env.example .env
```
Abra o `.env` e defina uma `SECRET_KEY` forte (o próprio arquivo mostra
como gerar uma).

### 5.5 Configurar o banco de dados

```bash
flask --app run.py init-db
flask --app run.py seed-data
```
Isso cria as tabelas e cadastra categorias, locais, status e unidades
padrão (você pode editar ou adicionar mais depois, pela área de Administração).

### 5.6 Criar o primeiro usuário administrador

```bash
flask --app run.py create-admin
```
Você será perguntado pelo nome, e-mail e senha do administrador.

### 5.7 Executar o sistema

```bash
python run.py
```

### 5.8 Acessar pelo navegador

Abra `http://localhost:5000` no computador.

Para acessar pelo **celular** enquanto testa localmente, use o IP da sua
máquina na rede Wi-Fi, por exemplo `http://192.168.0.10:5000` (o celular
precisa estar na mesma rede).

### 5.9 Preparar para hospedagem futura

Quando quiser colocar o sistema on-line para a equipe acessar de qualquer
lugar:

1. Escolha um provedor (Render, Railway, PythonAnywhere, um VPS, etc.).
2. Troque `DATABASE_URL` no `.env` do servidor para um PostgreSQL
   gerenciado (o código já está pronto para isso via SQLAlchemy).
3. Rode `flask --app run.py init-db` e `create-admin` no servidor.
4. Em produção, não use `debug=True` nem o servidor de desenvolvimento do
   Flask — use um servidor WSGI como `gunicorn` (`pip install gunicorn` e
   `gunicorn run:app`) atrás de um proxy como Nginx.
5. Configure HTTPS (a maioria dos provedores acima já oferece isso pronto).

---

## 6. Observações

- QR Code/código de barras não foram implementados agora, mas a estrutura
  (tabela `items` com id próprio) já permite adicionar isso depois sem
  redesenhar o banco.
- Fotos enviadas ficam em `app/static/uploads/` — ao migrar de servidor,
  copie essa pasta junto (ou migre para um serviço de armazenamento como
  S3 futuramente, se preferir).
- Para adicionar a logo da igreja, salve o arquivo de imagem em
  `app/static/img/logo.png` e referencie em `app/templates/base.html`
  no lugar do ícone `bi-buildings`.
