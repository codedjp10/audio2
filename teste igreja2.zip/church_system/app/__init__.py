import os
from flask import Flask
from dotenv import load_dotenv

from config import Config
from app.extensions import db, login_manager

load_dotenv()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Blueprints
    from app.auth.routes import auth_bp
    from app.main.routes import main_bp
    from app.items.routes import items_bp
    from app.stock.routes import stock_bp
    from app.events.routes import events_bp
    from app.admin.routes import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(items_bp, url_prefix="/itens")
    app.register_blueprint(stock_bp, url_prefix="/estoque")
    app.register_blueprint(events_bp, url_prefix="/eventos")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    from app.cli import register_commands
    register_commands(app)

    # Filtro para exibir data/hora em formato brasileiro nos templates
    @app.template_filter("dtbr")
    def dtbr(value, fmt="%d/%m/%Y %H:%M"):
        if not value:
            return "-"
        return value.strftime(fmt)

    @app.template_filter("dbr")
    def dbr(value, fmt="%d/%m/%Y"):
        if not value:
            return "-"
        return value.strftime(fmt)

    @app.context_processor
    def inject_globals():
        from datetime import datetime
        return {"now": datetime.utcnow()}

    @app.errorhandler(403)
    def forbidden(e):
        from flask import render_template
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        from flask import render_template
        return render_template("errors/404.html"), 404

    return app
