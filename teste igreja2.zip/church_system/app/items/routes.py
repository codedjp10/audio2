from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models import Item, Category, Location, Status, Movement, Event
from app.utils import log_action, save_photo, admin_required

items_bp = Blueprint("items", __name__)


@items_bp.route("/")
@login_required
def list_items():
    query = Item.query

    category_id = request.args.get("category_id", type=int)
    location_id = request.args.get("location_id", type=int)
    status_id = request.args.get("status_id", type=int)
    q = request.args.get("q", "").strip()

    if category_id:
        query = query.filter_by(category_id=category_id)
    if location_id:
        query = query.filter_by(current_location_id=location_id)
    if status_id:
        query = query.filter_by(status_id=status_id)
    if q:
        like = f"%{q}%"
        query = query.filter(
            db.or_(Item.name.ilike(like), Item.brand.ilike(like), Item.model.ilike(like))
        )

    items = query.order_by(Item.name).all()

    return render_template(
        "items/list.html",
        items=items,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        statuses=Status.query.order_by(Status.name).all(),
        filters=request.args,
    )


@items_bp.route("/novo", methods=["GET", "POST"])
@login_required
@admin_required
def create_item():
    if request.method == "POST":
        photo = save_photo(request.files.get("photo"))
        acquisition_date = request.form.get("acquisition_date") or None
        value = request.form.get("value") or None

        item = Item(
            name=request.form["name"].strip(),
            category_id=request.form["category_id"],
            brand=request.form.get("brand"),
            model=request.form.get("model"),
            serial_number=request.form.get("serial_number"),
            current_location_id=request.form["location_id"],
            status_id=request.form["status_id"],
            condition=request.form.get("condition"),
            photo_filename=photo,
            acquisition_date=datetime.strptime(acquisition_date, "%Y-%m-%d").date() if acquisition_date else None,
            value=value,
            notes=request.form.get("notes"),
        )
        db.session.add(item)
        db.session.commit()
        log_action("criar_item", f"{current_user.name} cadastrou o item '{item.name}'.")
        flash("Item cadastrado com sucesso.", "success")
        return redirect(url_for("items.item_detail", item_id=item.id))

    return render_template(
        "items/form.html",
        item=None,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        statuses=Status.query.order_by(Status.name).all(),
    )


@items_bp.route("/<int:item_id>/editar", methods=["GET", "POST"])
@login_required
@admin_required
def edit_item(item_id):
    item = Item.query.get_or_404(item_id)

    if request.method == "POST":
        item.name = request.form["name"].strip()
        item.category_id = request.form["category_id"]
        item.brand = request.form.get("brand")
        item.model = request.form.get("model")
        item.serial_number = request.form.get("serial_number")
        item.status_id = request.form["status_id"]
        item.condition = request.form.get("condition")
        item.notes = request.form.get("notes")
        value = request.form.get("value") or None
        item.value = value
        acquisition_date = request.form.get("acquisition_date") or None
        item.acquisition_date = datetime.strptime(acquisition_date, "%Y-%m-%d").date() if acquisition_date else None

        new_photo = save_photo(request.files.get("photo"))
        if new_photo:
            item.photo_filename = new_photo

        db.session.commit()
        log_action("editar_item", f"{current_user.name} editou o item '{item.name}'.")
        flash("Item atualizado com sucesso.", "success")
        return redirect(url_for("items.item_detail", item_id=item.id))

    return render_template(
        "items/form.html",
        item=item,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        statuses=Status.query.order_by(Status.name).all(),
    )


@items_bp.route("/<int:item_id>")
@login_required
def item_detail(item_id):
    item = Item.query.get_or_404(item_id)
    history = (
        Movement.query.filter_by(item_id=item.id)
        .order_by(Movement.moved_at.desc())
        .all()
    )
    return render_template("items/detail.html", item=item, history=history)


@items_bp.route("/<int:item_id>/retirar", methods=["GET", "POST"])
@login_required
def register_withdrawal(item_id):
    item = Item.query.get_or_404(item_id)

    if request.method == "POST":
        to_location_id = request.form["to_location_id"]
        expected_return_at = request.form.get("expected_return_at") or None
        new_status_name = request.form.get("new_status") or "Em uso"
        new_status = Status.query.filter_by(name=new_status_name).first()

        movement = Movement(
            item_id=item.id,
            from_location_id=item.current_location_id,
            to_location_id=to_location_id,
            responsible_name=request.form.get("responsible_name"),
            event_id=request.form.get("event_id") or None,
            expected_return_at=datetime.strptime(expected_return_at, "%Y-%m-%d").date() if expected_return_at else None,
            reason=request.form.get("reason"),
            notes=request.form.get("notes"),
            registered_by_user_id=current_user.id,
        )
        db.session.add(movement)

        item.current_location_id = to_location_id
        if new_status:
            item.status_id = new_status.id

        db.session.commit()
        log_action(
            "retirada",
            f"{current_user.name} registrou retirada de '{item.name}' para {movement.to_location.name}.",
        )
        flash("Retirada registrada com sucesso.", "success")
        return redirect(url_for("items.item_detail", item_id=item.id))

    return render_template(
        "items/movement_form.html",
        item=item,
        locations=Location.query.order_by(Location.name).all(),
        statuses=Status.query.order_by(Status.name).all(),
        events=Event.query.order_by(Event.date.desc()).all(),
    )


@items_bp.route("/<int:item_id>/devolver/<int:movement_id>", methods=["GET", "POST"])
@login_required
def register_return(item_id, movement_id):
    item = Item.query.get_or_404(item_id)
    movement = Movement.query.get_or_404(movement_id)

    if movement.item_id != item.id or not movement.is_open:
        flash("Esta movimentação já foi encerrada ou não pertence a este item.", "warning")
        return redirect(url_for("items.item_detail", item_id=item.id))

    if request.method == "POST":
        return_location_id = request.form["return_location_id"]
        available_status = Status.query.filter_by(name="Disponível").first()

        movement.returned_at = datetime.utcnow()
        movement.return_location_id = return_location_id
        movement.return_notes = request.form.get("return_notes")
        movement.returned_by_user_id = current_user.id

        item.current_location_id = return_location_id
        if available_status:
            item.status_id = available_status.id

        db.session.commit()
        log_action("devolucao", f"{current_user.name} registrou devolução de '{item.name}'.")
        flash("Devolução registrada com sucesso.", "success")
        return redirect(url_for("items.item_detail", item_id=item.id))

    return render_template(
        "items/return_form.html",
        item=item,
        movement=movement,
        locations=Location.query.order_by(Location.name).all(),
    )
