from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models import StockItem, Category, Location, Unit, StockMovement, Event
from app.utils import log_action, save_photo, admin_required

stock_bp = Blueprint("stock", __name__)


@stock_bp.route("/")
@login_required
def list_stock():
    query = StockItem.query

    category_id = request.args.get("category_id", type=int)
    location_id = request.args.get("location_id", type=int)
    only_low = request.args.get("low") == "1"
    q = request.args.get("q", "").strip()

    if category_id:
        query = query.filter_by(category_id=category_id)
    if location_id:
        query = query.filter_by(location_id=location_id)
    if q:
        query = query.filter(StockItem.name.ilike(f"%{q}%"))

    stock_items = query.order_by(StockItem.name).all()
    if only_low:
        stock_items = [s for s in stock_items if s.is_low]

    return render_template(
        "stock/list.html",
        stock_items=stock_items,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        filters=request.args,
    )


@stock_bp.route("/novo", methods=["GET", "POST"])
@login_required
@admin_required
def create_stock():
    if request.method == "POST":
        photo = save_photo(request.files.get("photo"))
        stock_item = StockItem(
            name=request.form["name"].strip(),
            category_id=request.form["category_id"],
            unit_id=request.form["unit_id"],
            quantity=float(request.form.get("quantity") or 0),
            min_quantity=float(request.form.get("min_quantity") or 0),
            location_id=request.form["location_id"],
            photo_filename=photo,
            notes=request.form.get("notes"),
        )
        db.session.add(stock_item)
        db.session.commit()
        log_action("criar_estoque", f"{current_user.name} cadastrou o material '{stock_item.name}'.")
        flash("Material cadastrado com sucesso.", "success")
        return redirect(url_for("stock.stock_detail", stock_id=stock_item.id))

    return render_template(
        "stock/form.html",
        stock_item=None,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        units=Unit.query.order_by(Unit.name).all(),
    )


@stock_bp.route("/<int:stock_id>/editar", methods=["GET", "POST"])
@login_required
@admin_required
def edit_stock(stock_id):
    stock_item = StockItem.query.get_or_404(stock_id)

    if request.method == "POST":
        stock_item.name = request.form["name"].strip()
        stock_item.category_id = request.form["category_id"]
        stock_item.unit_id = request.form["unit_id"]
        stock_item.min_quantity = float(request.form.get("min_quantity") or 0)
        stock_item.location_id = request.form["location_id"]
        stock_item.notes = request.form.get("notes")

        new_photo = save_photo(request.files.get("photo"))
        if new_photo:
            stock_item.photo_filename = new_photo

        db.session.commit()
        log_action("editar_estoque", f"{current_user.name} editou o material '{stock_item.name}'.")
        flash("Material atualizado com sucesso.", "success")
        return redirect(url_for("stock.stock_detail", stock_id=stock_item.id))

    return render_template(
        "stock/form.html",
        stock_item=stock_item,
        categories=Category.query.order_by(Category.name).all(),
        locations=Location.query.order_by(Location.name).all(),
        units=Unit.query.order_by(Unit.name).all(),
    )


@stock_bp.route("/<int:stock_id>")
@login_required
def stock_detail(stock_id):
    stock_item = StockItem.query.get_or_404(stock_id)
    history = (
        StockMovement.query.filter_by(stock_item_id=stock_item.id)
        .order_by(StockMovement.created_at.desc())
        .all()
    )
    return render_template("stock/detail.html", stock_item=stock_item, history=history)


@stock_bp.route("/<int:stock_id>/entrada", methods=["GET", "POST"])
@login_required
def register_entry(stock_id):
    stock_item = StockItem.query.get_or_404(stock_id)

    if request.method == "POST":
        quantity = float(request.form["quantity"])
        previous = stock_item.quantity
        stock_item.quantity = previous + quantity

        movement = StockMovement(
            stock_item_id=stock_item.id,
            type="entrada",
            quantity=quantity,
            previous_quantity=previous,
            new_quantity=stock_item.quantity,
            user_id=current_user.id,
            reason=request.form.get("reason"),
            supplier=request.form.get("supplier"),
            notes=request.form.get("notes"),
        )
        db.session.add(movement)
        db.session.commit()
        log_action(
            "entrada_estoque",
            f"{current_user.name} registrou entrada de {quantity} em '{stock_item.name}'.",
        )
        flash("Entrada registrada com sucesso.", "success")
        return redirect(url_for("stock.stock_detail", stock_id=stock_item.id))

    return render_template("stock/in_form.html", stock_item=stock_item)


@stock_bp.route("/<int:stock_id>/saida", methods=["GET", "POST"])
@login_required
def register_exit(stock_id):
    stock_item = StockItem.query.get_or_404(stock_id)

    if request.method == "POST":
        quantity = float(request.form["quantity"])

        if quantity > stock_item.quantity:
            flash(
                f"Quantidade insuficiente em estoque. Disponível: {stock_item.quantity} {stock_item.unit.name}.",
                "danger",
            )
            return redirect(url_for("stock.register_exit", stock_id=stock_item.id))

        previous = stock_item.quantity
        stock_item.quantity = previous - quantity

        movement = StockMovement(
            stock_item_id=stock_item.id,
            type="saida",
            quantity=quantity,
            previous_quantity=previous,
            new_quantity=stock_item.quantity,
            user_id=current_user.id,
            reason=request.form.get("reason"),
            destination_location_id=request.form.get("destination_location_id") or None,
            event_id=request.form.get("event_id") or None,
            notes=request.form.get("notes"),
        )
        db.session.add(movement)
        db.session.commit()
        log_action(
            "saida_estoque",
            f"{current_user.name} registrou saída de {quantity} em '{stock_item.name}'.",
        )
        flash("Saída registrada com sucesso.", "success")
        return redirect(url_for("stock.stock_detail", stock_id=stock_item.id))

    return render_template(
        "stock/out_form.html",
        stock_item=stock_item,
        locations=Location.query.order_by(Location.name).all(),
        events=Event.query.order_by(Event.date.desc()).all(),
    )
