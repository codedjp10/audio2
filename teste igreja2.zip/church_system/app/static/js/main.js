// Fecha os alertas automaticamente após alguns segundos
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".alert").forEach(function (alertEl) {
    setTimeout(function () {
      const alert = bootstrap.Alert.getOrCreateInstance(alertEl);
      alert.close();
    }, 5000);
  });
});
