from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models import User, Category, Location, Status, Unit, AuditLog
from app.utils import log_action, admin_required

admin_bp = Blueprint("admin", __name__)


# ---------------------------------------------------------------------------
# Usuários
# ---------------------------------------------------------------------------
@admin_bp.route("/usuarios")
@login_required
@admin_required
def list_users():
    users = User.query.order_by(User.name).all()
    return render_template("admin/users.html", users=users)


@admin_bp.route("/usuarios/novo", methods=["GET", "POST"])
@login_required
@admin_required
def create_user():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        if User.query.filter_by(email=email).first():
            flash("Já existe um usuário com este e-mail.", "danger")
            return redirect(url_for("admin.create_user"))

        user = User(
            name=request.form["name"].strip(),
            email=email,
            role=request.form.get("role", "membro"),
            active=True,
        )
        user.set_password(request.form["password"])
        db.session.add(user)
        db.session.commit()
        log_action("criar_usuario", f"{current_user.name} cadastrou o usuário '{user.name}'.")
        flash("Usuário cadastrado com sucesso.", "success")
        return redirect(url_for("admin.list_users"))

    return render_template("admin/user_form.html", user=None)


@admin_bp.route("/usuarios/<int:user_id>/editar", methods=["GET", "POST"])
@login_required
@admin_required
def edit_user(user_id):
    user = User.query.get_or_404(user_id)

    if request.method == "POST":
        user.name = request.form["name"].strip()
        user.role = request.form.get("role", user.role)
        user.active = bool(request.form.get("active"))
        new_password = request.form.get("password")
        if new_password:
            user.set_password(new_password)
        db.session.commit()
        log_action("editar_usuario", f"{current_user.name} editou o usuário '{user.name}'.")
        flash("Usuário atualizado com sucesso.", "success")
        return redirect(url_for("admin.list_users"))

    return render_template("admin/user_form.html", user=user)


# ---------------------------------------------------------------------------
# Categorias
# ---------------------------------------------------------------------------
@admin_bp.route("/categorias", methods=["GET", "POST"])
@login_required
@admin_required
def manage_categories():
    if request.method == "POST":
        name = request.form["name"].strip()
        icon = request.form.get("icon", "📦").strip() or "📦"
        if name and not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name, icon=icon))
            db.session.commit()
            log_action("criar_categoria", f"{current_user.name} criou a categoria '{name}'.")
            flash("Categoria criada com sucesso.", "success")
        else:
            flash("Categoria inválida ou já existente.", "warning")
        return redirect(url_for("admin.manage_categories"))

    categories = Category.query.order_by(Category.name).all()
    return render_template("admin/categories.html", categories=categories)


@admin_bp.route("/categorias/<int:category_id>/excluir", methods=["POST"])
@login_required
@admin_required
def delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    if category.items or category.stock_items:
        flash("Não é possível excluir: existem itens vinculados a esta categoria.", "danger")
    else:
        db.session.delete(category)
        db.session.commit()
        log_action("excluir_categoria", f"{current_user.name} excluiu a categoria '{category.name}'.")
        flash("Categoria excluída.", "success")
    return redirect(url_for("admin.manage_categories"))


# ---------------------------------------------------------------------------
# Locais
# ---------------------------------------------------------------------------
@admin_bp.route("/locais", methods=["GET", "POST"])
@login_required
@admin_required
def manage_locations():
    if request.method == "POST":
        name = request.form["name"].strip()
        if name and not Location.query.filter_by(name=name).first():
            db.session.add(Location(name=name))
            db.session.commit()
            log_action("criar_local", f"{current_user.name} criou o local '{name}'.")
            flash("Local criado com sucesso.", "success")
        else:
            flash("Local inválido ou já existente.", "warning")
        return redirect(url_for("admin.manage_locations"))

    locations = Location.query.order_by(Location.name).all()
    return render_template("admin/locations.html", locations=locations)


@admin_bp.route("/locais/<int:location_id>/excluir", methods=["POST"])
@login_required
@admin_required
def delete_location(location_id):
    location = Location.query.get_or_404(location_id)
    if location.items or location.stock_items:
        flash("Não é possível excluir: existem itens vinculados a este local.", "danger")
    else:
        db.session.delete(location)
        db.session.commit()
        log_action("excluir_local", f"{current_user.name} excluiu o local '{location.name}'.")
        flash("Local excluído.", "success")
    return redirect(url_for("admin.manage_locations"))


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
@admin_bp.route("/status", methods=["GET", "POST"])
@login_required
@admin_required
def manage_statuses():
    if request.method == "POST":
        name = request.form["name"].strip()
        color = request.form.get("color", "secondary")
        if name and not Status.query.filter_by(name=name).first():
            db.session.add(Status(name=name, color=color))
            db.session.commit()
            log_action("criar_status", f"{current_user.name} criou o status '{name}'.")
            flash("Status criado com sucesso.", "success")
        else:
            flash("Status inválido ou já existente.", "warning")
        return redirect(url_for("admin.manage_statuses"))

    statuses = Status.query.order_by(Status.name).all()
    return render_template("admin/statuses.html", statuses=statuses)


# ---------------------------------------------------------------------------
# Unidades de medida
# ---------------------------------------------------------------------------
@admin_bp.route("/unidades", methods=["GET", "POST"])
@login_required
@admin_required
def manage_units():
    if request.method == "POST":
        name = request.form["name"].strip()
        if name and not Unit.query.filter_by(name=name).first():
            db.session.add(Unit(name=name))
            db.session.commit()
            log_action("criar_unidade", f"{current_user.name} criou a unidade '{name}'.")
            flash("Unidade criada com sucesso.", "success")
        else:
            flash("Unidade inválida ou já existente.", "warning")
        return redirect(url_for("admin.manage_units"))

    units = Unit.query.order_by(Unit.name).all()
    return render_template("admin/units.html", units=units)


# ---------------------------------------------------------------------------
# Auditoria
# ---------------------------------------------------------------------------
@admin_bp.route("/auditoria")
@login_required
@admin_required
def audit_log():
    page = request.args.get("page", 1, type=int)
    logs = (
        AuditLog.query.order_by(AuditLog.created_at.desc())
        .paginate(page=page, per_page=50, error_out=False)
    )
    return render_template("admin/audit.html", logs=logs)
