from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models import Event, Location, Movement, StockMovement
from app.utils import log_action, admin_required

events_bp = Blueprint("events", __name__)


@events_bp.route("/")
@login_required
def list_events():
    events = Event.query.order_by(Event.date.desc()).all()
    return render_template("events/list.html", events=events)


@events_bp.route("/novo", methods=["GET", "POST"])
@login_required
@admin_required
def create_event():
    if request.method == "POST":
        time_str = request.form.get("time") or None
        event = Event(
            name=request.form["name"].strip(),
            date=datetime.strptime(request.form["date"], "%Y-%m-%d").date(),
            time=datetime.strptime(time_str, "%H:%M").time() if time_str else None,
            location_id=request.form.get("location_id") or None,
            responsible_name=request.form.get("responsible_name"),
            description=request.form.get("description"),
            notes=request.form.get("notes"),
            status=request.form.get("status", "Planejado"),
        )
        db.session.add(event)
        db.session.commit()
        log_action("criar_evento", f"{current_user.name} cadastrou o evento '{event.name}'.")
        flash("Evento cadastrado com sucesso.", "success")
        return redirect(url_for("events.event_detail", event_id=event.id))

    return render_template(
        "events/form.html", event=None, locations=Location.query.order_by(Location.name).all()
    )


@events_bp.route("/<int:event_id>/editar", methods=["GET", "POST"])
@login_required
@admin_required
def edit_event(event_id):
    event = Event.query.get_or_404(event_id)

    if request.method == "POST":
        time_str = request.form.get("time") or None
        event.name = request.form["name"].strip()
        event.date = datetime.strptime(request.form["date"], "%Y-%m-%d").date()
        event.time = datetime.strptime(time_str, "%H:%M").time() if time_str else None
        event.location_id = request.form.get("location_id") or None
        event.responsible_name = request.form.get("responsible_name")
        event.description = request.form.get("description")
        event.notes = request.form.get("notes")
        event.status = request.form.get("status", event.status)
        db.session.commit()
        log_action("editar_evento", f"{current_user.name} editou o evento '{event.name}'.")
        flash("Evento atualizado com sucesso.", "success")
        return redirect(url_for("events.event_detail", event_id=event.id))

    return render_template(
        "events/form.html", event=event, locations=Location.query.order_by(Location.name).all()
    )


@events_bp.route("/<int:event_id>")
@login_required
def event_detail(event_id):
    event = Event.query.get_or_404(event_id)
    item_movements = (
        Movement.query.filter_by(event_id=event.id).order_by(Movement.moved_at.desc()).all()
    )
    stock_movements = (
        StockMovement.query.filter_by(event_id=event.id)
        .order_by(StockMovement.created_at.desc())
        .all()
    )
    return render_template(
        "events/detail.html",
        event=event,
        item_movements=item_movements,
        stock_movements=stock_movements,
    )
