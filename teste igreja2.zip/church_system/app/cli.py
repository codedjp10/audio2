import click
from flask.cli import with_appcontext

from app.extensions import db
from app.models import Category, Location, Status, Unit, User

DEFAULT_CATEGORIES = [
    ("🎤", "Equipamentos de Áudio"),
    ("🎸", "Instrumentos"),
    ("🔧", "Ferramentas"),
    ("💡", "Iluminação"),
    ("📹", "Vídeo"),
    ("💻", "Informática"),
    ("🔌", "Conectores e Acessórios"),
    ("📦", "Materiais"),
]

DEFAULT_LOCATIONS = [
    "Salão Principal",
    "Salão de Jovens",
    "Salão Infantil",
    "Depósito",
    "Almoxarifado",
    "Escritório",
    "Sala de Música",
    "Sala de Áudio",
]

DEFAULT_STATUSES = [
    ("Disponível", "success"),
    ("Em uso", "danger"),
    ("Emprestado", "warning"),
    ("Em manutenção", "warning"),
    ("Indisponível", "secondary"),
]

DEFAULT_UNITS = [
    "Unidade", "Caixa", "Pacote", "Metro", "Litro",
    "Quilograma", "Rolo", "Par", "Kit", "Outro",
]


@click.command("init-db")
@with_appcontext
def init_db_command():
    """Cria todas as tabelas do banco de dados (não apaga dados existentes)."""
    db.create_all()
    click.echo("Banco de dados inicializado (tabelas criadas).")


@click.command("seed-data")
@with_appcontext
def seed_data_command():
    """Cadastra categorias, locais, status e unidades padrão, se ainda não existirem."""
    for icon, name in DEFAULT_CATEGORIES:
        if not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name, icon=icon))

    for name in DEFAULT_LOCATIONS:
        if not Location.query.filter_by(name=name).first():
            db.session.add(Location(name=name))

    for name, color in DEFAULT_STATUSES:
        if not Status.query.filter_by(name=name).first():
            db.session.add(Status(name=name, color=color))

    for name in DEFAULT_UNITS:
        if not Unit.query.filter_by(name=name).first():
            db.session.add(Unit(name=name))

    db.session.commit()
    click.echo("Dados padrão cadastrados: categorias, locais, status e unidades.")


@click.command("create-admin")
@click.option("--name", prompt="Nome completo")
@click.option("--email", prompt="E-mail")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True)
@with_appcontext
def create_admin_command(name, email, password):
    """Cria um usuário administrador."""
    email = email.strip().lower()
    if User.query.filter_by(email=email).first():
        click.echo("Já existe um usuário com este e-mail.")
        return

    user = User(name=name.strip(), email=email, role="admin", active=True)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    click.echo(f"Administrador '{name}' criado com sucesso.")


def register_commands(app):
    app.cli.add_command(init_db_command)
    app.cli.add_command(seed_data_command)
    app.cli.add_command(create_admin_command)
