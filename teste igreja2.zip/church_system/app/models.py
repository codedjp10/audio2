from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from app.extensions import db


# ---------------------------------------------------------------------------
# Usuários
# ---------------------------------------------------------------------------
class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="membro")  # 'admin' ou 'membro'
    active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == "admin"

    def __repr__(self):
        return f"<User {self.email}>"


# ---------------------------------------------------------------------------
# Tabelas de apoio (cadastráveis pelo administrador, sem alterar código)
# ---------------------------------------------------------------------------
class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    icon = db.Column(db.String(10), default="📦")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Location(db.Model):
    __tablename__ = "locations"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Status(db.Model):
    __tablename__ = "statuses"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    color = db.Column(db.String(20), default="secondary")  # cor do badge bootstrap


class Unit(db.Model):
    __tablename__ = "units"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)


# ---------------------------------------------------------------------------
# Itens individuais (equipamentos, instrumentos, ferramentas, cabos completos)
# ---------------------------------------------------------------------------
class Item(db.Model):
    __tablename__ = "items"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    brand = db.Column(db.String(100))
    model = db.Column(db.String(100))
    serial_number = db.Column(db.String(100))
    current_location_id = db.Column(db.Integer, db.ForeignKey("locations.id"), nullable=False)
    status_id = db.Column(db.Integer, db.ForeignKey("statuses.id"), nullable=False)
    condition = db.Column(db.String(50))  # estado de conservação
    photo_filename = db.Column(db.String(255))
    acquisition_date = db.Column(db.Date)
    value = db.Column(db.Numeric(10, 2))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    category = db.relationship("Category", backref="items")
    current_location = db.relationship("Location", backref="items")
    status = db.relationship("Status", backref="items")

    @property
    def last_movement(self):
        return (
            Movement.query.filter_by(item_id=self.id)
            .order_by(Movement.moved_at.desc())
            .first()
        )


class Movement(db.Model):
    """Registro de retirada/devolução de um item individual. Nunca é apagado."""

    __tablename__ = "movements"

    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey("items.id"), nullable=False)

    from_location_id = db.Column(db.Integer, db.ForeignKey("locations.id"))
    to_location_id = db.Column(db.Integer, db.ForeignKey("locations.id"), nullable=False)

    responsible_name = db.Column(db.String(120))  # pessoa que ficou responsável
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"))

    moved_at = db.Column(db.DateTime, default=datetime.utcnow)
    expected_return_at = db.Column(db.Date)
    reason = db.Column(db.String(255))
    notes = db.Column(db.Text)

    returned_at = db.Column(db.DateTime)
    return_location_id = db.Column(db.Integer, db.ForeignKey("locations.id"))
    return_notes = db.Column(db.Text)
    returned_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    registered_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    item = db.relationship("Item", backref=db.backref("movements", order_by="Movement.moved_at.desc()"))
    from_location = db.relationship("Location", foreign_keys=[from_location_id])
    to_location = db.relationship("Location", foreign_keys=[to_location_id])
    return_location = db.relationship("Location", foreign_keys=[return_location_id])
    event = db.relationship("Event", backref="movements")
    registered_by = db.relationship("User", foreign_keys=[registered_by_user_id])
    returned_by = db.relationship("User", foreign_keys=[returned_by_user_id])

    @property
    def is_open(self):
        """True se o item ainda não foi devolvido nesta movimentação."""
        return self.returned_at is None

    @property
    def is_late(self):
        return (
            self.is_open
            and self.expected_return_at is not None
            and self.expected_return_at < datetime.utcnow().date()
        )


# ---------------------------------------------------------------------------
# Estoque (materiais, conectores e acessórios avulsos, controlados por quantidade)
# ---------------------------------------------------------------------------
class StockItem(db.Model):
    __tablename__ = "stock_items"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey("units.id"), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=0)
    min_quantity = db.Column(db.Float, nullable=False, default=0)
    location_id = db.Column(db.Integer, db.ForeignKey("locations.id"), nullable=False)
    photo_filename = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    category = db.relationship("Category", backref="stock_items")
    unit = db.relationship("Unit", backref="stock_items")
    location = db.relationship("Location", backref="stock_items")

    @property
    def is_low(self):
        return self.quantity <= self.min_quantity


class StockMovement(db.Model):
    """Entrada ou saída de um item de estoque. Nunca é apagado."""

    __tablename__ = "stock_movements"

    id = db.Column(db.Integer, primary_key=True)
    stock_item_id = db.Column(db.Integer, db.ForeignKey("stock_items.id"), nullable=False)
    type = db.Column(db.String(10), nullable=False)  # 'entrada' ou 'saida'
    quantity = db.Column(db.Float, nullable=False)
    previous_quantity = db.Column(db.Float, nullable=False)
    new_quantity = db.Column(db.Float, nullable=False)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    reason = db.Column(db.String(255))
    supplier = db.Column(db.String(150))  # usado em entradas
    destination_location_id = db.Column(db.Integer, db.ForeignKey("locations.id"))  # usado em saídas
    event_id = db.Column(db.Integer, db.ForeignKey("events.id"))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    stock_item = db.relationship("StockItem", backref=db.backref("movements", order_by="StockMovement.created_at.desc()"))
    user = db.relationship("User")
    destination_location = db.relationship("Location")
    event = db.relationship("Event", backref="stock_movements")


# ---------------------------------------------------------------------------
# Eventos
# ---------------------------------------------------------------------------
class Event(db.Model):
    __tablename__ = "events"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time)
    location_id = db.Column(db.Integer, db.ForeignKey("locations.id"))
    responsible_name = db.Column(db.String(120))
    description = db.Column(db.Text)
    notes = db.Column(db.Text)
    status = db.Column(db.String(30), default="Planejado")  # Planejado, Em andamento, Concluído, Cancelado
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    location = db.relationship("Location", backref="events")


# ---------------------------------------------------------------------------
# Auditoria
# ---------------------------------------------------------------------------
class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    action = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User")
