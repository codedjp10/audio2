from datetime import datetime, timedelta

from flask import Blueprint, render_template, request
from flask_login import login_required
from sqlalchemy import or_

from app.extensions import db
from app.models import Item, StockItem, Movement, StockMovement, Event, Status, AuditLog

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
@login_required
def dashboard():
    total_items = Item.query.count()

    disponivel = Status.query.filter_by(name="Disponível").first()
    em_uso = Status.query.filter_by(name="Em uso").first()
    manutencao = Status.query.filter_by(name="Em manutenção").first()

    count_disponivel = Item.query.filter_by(status_id=disponivel.id).count() if disponivel else 0
    count_em_uso = Item.query.filter_by(status_id=em_uso.id).count() if em_uso else 0
    count_manutencao = Item.query.filter_by(status_id=manutencao.id).count() if manutencao else 0

    hoje = datetime.utcnow().date()
    atrasadas = (
        Movement.query.filter(
            Movement.returned_at.is_(None),
            Movement.expected_return_at.isnot(None),
            Movement.expected_return_at < hoje,
        )
        .order_by(Movement.expected_return_at)
        .all()
    )

    total_stock = StockItem.query.count()
    low_stock = StockItem.query.filter(StockItem.quantity <= StockItem.min_quantity).all()

    proximos_eventos = (
        Event.query.filter(Event.date >= hoje).order_by(Event.date).limit(5).all()
    )
    eventos_andamento = Event.query.filter_by(status="Em andamento").all()

    recentes = (
        AuditLog.query.order_by(AuditLog.created_at.desc()).limit(10).all()
    )

    return render_template(
        "main/dashboard.html",
        total_items=total_items,
        count_disponivel=count_disponivel,
        count_em_uso=count_em_uso,
        count_manutencao=count_manutencao,
        atrasadas=atrasadas,
        total_stock=total_stock,
        low_stock=low_stock,
        proximos_eventos=proximos_eventos,
        eventos_andamento=eventos_andamento,
        recentes=recentes,
    )


@main_bp.route("/buscar")
@login_required
def search():
    q = request.args.get("q", "").strip()
    items_result = []
    stock_result = []

    if q:
        like = f"%{q}%"
        items_result = Item.query.filter(
            or_(Item.name.ilike(like), Item.brand.ilike(like), Item.model.ilike(like))
        ).all()
        stock_result = StockItem.query.filter(StockItem.name.ilike(like)).all()

    return render_template(
        "main/search.html", q=q, items_result=items_result, stock_result=stock_result
    )
