import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))
instance_dir = os.path.join(basedir, "instance")
os.makedirs(instance_dir, exist_ok=True)


class Config:
    """Configuração base. Valores sensíveis vêm de variáveis de ambiente."""

    SECRET_KEY = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")

    # Banco de dados: SQLite por padrão. Para migrar para PostgreSQL no
    # futuro, basta definir a variável de ambiente DATABASE_URL, por
    # exemplo: postgresql://usuario:senha@host:5432/nome_do_banco
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(instance_dir, 'igreja.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = os.path.join(basedir, "app", "static", "uploads")
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 MB por upload de foto

    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)

    # Nome e status usados como padrão em vários lugares do sistema
    STATUS_PADRAO = ["Disponível", "Em uso", "Emprestado", "Em manutenção", "Indisponível"]
    UNIDADES_PADRAO = ["Unidade", "Caixa", "Pacote", "Metro", "Litro", "Quilograma", "Rolo", "Par", "Kit", "Outro"]
