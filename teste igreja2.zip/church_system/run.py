from app import create_app

app = create_app()

if __name__ == "__main__":
    # host="0.0.0.0" permite acesso de outros dispositivos na mesma rede
    # (ex: celular da equipe conectado ao mesmo Wi-Fi da igreja)
    app.run(host="0.0.0.0", port=5000, debug=True)
